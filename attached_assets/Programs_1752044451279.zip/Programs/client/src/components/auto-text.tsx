import React, { ReactNode } from 'react';

interface AutoTextProps {
  children: ReactNode;
  className?: string;
}

// Simplified component that just displays text without translation
export function AutoText({ children, className, ...props }: AutoTextProps & React.HTMLAttributes<HTMLSpanElement>) {
  return <span className={className} {...props}>{children}</span>;
}

// Wrapper that returns component without translation
export function withAutoTranslation<P extends object>(
  WrappedComponent: React.ComponentType<P>
): React.ComponentType<P> {
  return function AutoTranslatedComponent(props: P) {
    return <WrappedComponent {...props} />;
  };
}

// Simple hook that returns text as-is
export function useAutoText() {
  return (text: string) => text;
}