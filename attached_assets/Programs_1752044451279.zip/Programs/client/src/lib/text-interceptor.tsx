import React from 'react';
import { useLanguage } from './LanguageProvider';

// Simple translation hook that returns text as-is
export function useTextTranslation() {
  return {
    t: (text: string) => text,
    isLoading: false
  };
}

// Simple translation service that returns text unchanged
export class SimpleTranslationService {
  async translateText(text: string, targetLanguage: string): Promise<string> {
    return text;
  }
  
  async translateTexts(texts: string[], targetLanguage: string): Promise<string[]> {
    return texts;
  }
}

export const translationService = new SimpleTranslationService();